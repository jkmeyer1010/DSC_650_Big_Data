---
title: Assignment 1
subtitle: Computer performance, reliability, and scalability calculation
author: Jake Meyer
---

## 1.2 

#### a. Data Sizes

| Data Item                                  | Size per Item | 
|--------------------------------------------|--------------:|
| 128 character message.                     |     128 Bytes |
| 1024x768 PNG image                         |       3.15 MB |
| 1024x768 RAW image                         |       1.57 MB | 
| HD (1080p) HEVC Video (15 minutes)         |    224,004 MB |
| HD (1080p) Uncompressed Video (15 minutes) |    167,962 MB |
| 4K UHD HEVC Video (15 minutes)             |   5,062.50 MB |
| 4k UHD Uncompressed Video (15 minutes)     | 160,180.66 MB |
| Human Genome (Uncompressed)                |       ~200 GB |

Assumptions: <br>
1. All videos are 30 frames per second.
2. HEVC stands for High Efficiency Video Coding
3. See the Wikipedia article on display resolution for information <br>
on HD (1080p) and 4K UHD resolutions.

Calculations: <br>
1 byte = 1 letter in computer memory therefore 128 characters* 1 byte = 128 Bytes <br>
[Image Size Calculator](https://toolstud.io/photo/filesize.php?imagewidth=1024&imageheight=768) <br>
PNG Image File Uncompressed 4x8bit RGBA <br>
Raw Image FIle Uncompressed 16bit monochrome <br>
[Video Size Calculator](https://www.omnicalculator.com/other/video-size) <br>
HD (1080p) Cineon 1080 RGB, 15 minute video, 30 frames per second <br>
HD (1080p) Uncompressed 1080 8-bit, 15 minute video, 30 frames per second <br>
[4K Video Size Calculator](https://www.videoproc.com/edit-4k-video/video-size-calculator.htm) <br>
4K UHD HEVC Video Resolution 3840 x 2160 from Wikipedia, 15 minutes, 30 frames per second <br>
4K UHD HEVC Uncompressed Resolution 1920 x 1080 pixels, 15 minutes, 30 frames per second <br>
[Human Genome Reference](https://medium.com/precision-medicine/how-big-is-the-human-genome-e90caa3409b0) <br>

#### b. Scaling

|                                           |                 Size |       # HD | 
|-------------------------------------------|---------------------:|-----------:|
| Daily Twitter Tweets (Uncompressed)       |            178.81 GB |          1 |
| Daily Twitter Tweets (Snappy Compressed)  |          3,039.83 GB |          1 |
| Daily Instagram Photos                    |        692,138.67 GB |        676 |
| Daily YouTube Videos                      |     78,751,406.25 GB |     76,906 |
| Yearly Twitter Tweets (Uncompressed)      |         65,267.08 GB |         64 |
| Yearly Twitter Tweets (Snappy Compressed) |      1,109,540.46 GB |      1,084 |
| Yearly Instagram Photos                   |    252,630,859.38 GB |    246,710 |
| Yearly YouTube Videos                     | 28,744,263,281.25 GB | 28,070,570 |


Assumptions: <br>
1. Using the estimates for data sizes in part a.
2. Using 10 TB Hard Drives and storing the data using the Hadoop Distributed File System (HDFS). 3x the amount of storage required. <br>
3. 500 million tweets sent each day. Each tweet is 128 characters. Snappy compression ratio assumed 1:1.7.
4. 100 million videos and photos are uploaded to Instagram daily. 75% of those items are 1024x768PNG photos.
5. Youtube estimates 500 hours of video uploaded every minute. All videos are HD quality encoded using HEVC at 30 fps. <br>

Calculations: <br>
Method used for calculations was to find the size initially for each request. <br>
Ensure the data size is multiplied by 3 since using HDFS. <br>
Use [Data Size Calculator](https://www.calculator.com/calculate/data-size/) to understand amount in Terabytes. <br>
Daily Twitter Tweets Size = 128 bytes * 500 million tweets * 3 <br>
Daily Twitter Tweets Compressed Size = 128 bytes * 1.7 Compression Ratio * 500 million tweets * 3 <br>
Daily Instagram Photos Size = 3.15 MB * 100,000,000 photos * .75 * 3 <br>
Daily Youtube Videos Size = 224,004 MB * 4 * 500 hours of video * 60 minutes * 3 <br>
Yearly Twitter Tweets Size = 128 bytes * 500 million tweets * 365 days * 3 <br>
Yearly Twitter Tweets Compressed Size = 128 bytes * 1.7 Compression Ratio * 500 million tweets * 365 days * 3 <br>
Yearly Instagram Photos Size = 3.15 MB * 100,000,000 photos * .75 * 365 days * 3 <br>
Yearly Youtube Videos Size = 224,004 MB * 4 * 500 hours of video * 60 minutes * 365 days* 3 <br>

#### c. Reliability

|                                    |       # HD | # Failures |
|------------------------------------|-----------:|-----------:|
| Twitter Tweets (Uncompressed)      |         64 |          1 |
| Twitter Tweets (Snappy Compressed) |      1,084 |         15 |
| Instagram Photos                   |    246,710 |      3,380 |
| YouTube Videos                     | 28,080,570 |    384,704 |

Assumptions: <br>
1. Use the yearly estimates from part b. <br>

Calculations: <br>
[According to Backblaze hard drive statistics](https://www.backblaze.com/b2/hard-drive-test-data.html), <br> 
annual failure rate is 1.37%. Calculations will be: <br>
Annual Number of Hard Drive Failures = Number of HD * 0.0137 <br>
Rounded to the nearest whole hard drive.
#### d. Latency

|                           | One Way Latency |
|---------------------------|----------------:|
| Los Angeles to Amsterdam  |        70.36 ms |
| Low Earth Orbit Satellite |          100 ms |
| Geostationary Satellite   |          140 ms |
| Earth to the Moon         |        1,280 ms |
| Earth to Mars             |      20 minutes | 

Calculations: <br>
[Global Ping Statistics](https://wondernetwork.com/pings) used for latency from Los Angeles to Amsterdam <br>
Los Angeles to Amsterdam = 140.72 ms / 2 <br>
[Low to Medium Earth Orbit Satellite](https://www.satellitetoday.com/telecom/2009/09/01/minimizing-latency-in-satellite-networks/) <br>
Low to Medium Earth Orbit Satellite = 100 ms taken from the article. <br>
[Geostationary Satellite Latency](https://www.satsig.net/latency.htm) <br>
Geostationary Satellite = 280 ms / 2 <br>
[Earth to Moon and Earth to Mars](https://short-informer.com/what-is-the-latency-between-earth-and-moon/#:~:text=What%20is%20the%20latency%20between%20earth%20and%20moon%3F,to%20about%205.8%20milliseconds%20of%20wave%20travel%20time.) <br>
Earth to Moon = 2,560 ms / 2 <br>
Earth to Mars = 20 minutes on average (from reference above)

